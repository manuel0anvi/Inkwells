'use strict';

/* ══════════════════════════════════════════════════════════════════════
   ÖRTLICHE ZUGANGSDATEN  ―  NICHT INS REPO

   Diese Datei steht in .gitignore. Sie bleibt auf diesem Rechner.
   Wer das Projekt neu auscheckt, kopiert sich
   cloudConfig.local.example.js hierher und trägt den Wert selbst ein.
   ══════════════════════════════════════════════════════════════════════ */

window.GOOGLE_CLIENT_SECRET_LOCAL = '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';
